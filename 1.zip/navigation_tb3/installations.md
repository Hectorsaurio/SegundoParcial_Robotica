## Packages to install
- sudo apt-get install ros-humble-nav2-costmap-2d
- sudo apt-get install ros-humble-nav2-core
- sudo apt-get install ros-humble-nav2-behaviors
- sudo apt-get install ros-humble-robot-localization
- sudo apt-get install ros-humble-gazebo-ros-pkgs
- sudo apt-get install ros-humble-turtlebot3-msgs
- sudo apt-get install ros-humble-nav2-map-server
- sudo apt install ros-humble-nav2-bringup