#ifndef _CONFIG_H
#define _CONFIG_H

#define PROJECT "Stage"
#define VERSION "4.3.0"
#define FULL_VERSION 4-3-0
#define APIVERSION "4.3"
#define INSTALL_PREFIX "/home/hector/Desktop/cato1/cato/install/Stage"
#define PLUGIN_PATH "/home/hector/Desktop/cato1/cato/install/Stage/lib/Stage-4.3"

/* #undef BUILD_GUI */

#endif
